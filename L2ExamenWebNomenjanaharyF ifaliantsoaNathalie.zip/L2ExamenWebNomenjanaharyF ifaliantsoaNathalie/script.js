let data = [];

async function take(){
    let livre = await fetch("./stock.json").then((resp) => resp.json());
    return livre
}

data = await take();
// console.log(data);

function lister(data){
    const container = document.querySelector(".livres-container");

    data.forEach(livre => {
        const div = document.createElement("div");
        const img = document.createElement("img");
        const title = document.createElement("h2");
        const span = document.createElement("span");
        const auteur = document.createElement("h2");

        div.classList.add("livre");

        div.addEventListener("click",(e) => {
            details(livre)
        })

        img.src = livre.img;
        title.textContent = livre.titre;
        span.textContent = "par";
        auteur.textContent = livre.auteur;

        div.appendChild(img);
        div.appendChild(title);
        div.appendChild(span);
        div.appendChild(auteur);

        container.appendChild(div);
    })
}

lister(data);

function details(livre) {
    const container = document.querySelector(".details");
    const div = document.createElement('div');
    const h2 = document.createElement('h2');
    h2.textContent = "Détails";
    const span = document.createElement("span");
    span.textContent = "X";
    span.style.cursor = "pointer";
    span.addEventListener("click",(e) => {
        container.innerHTML = "";
        container.style.display = "none";
    })

    div.appendChild(h2);
    div.appendChild(span);
    container.appendChild(div)

    const img = document.createElement("img");
        const title = document.createElement("h2");
        const par = document.createElement("span");
        const auteur = document.createElement("h2");

        img.src = livre.img;
        title.textContent = livre.titre;
        par.textContent = "par";
        auteur.textContent = livre.auteur;

        const edit = document.createElement("h4")
        const date = document.createElement("h4")
        const genre = document.createElement("h4")
        const langue = document.createElement("h4")
        const nbr = document.createElement("h4")
        const isbn = document.createElement("h4")
        const etat = document.createElement("h4")
        const dispo = document.createElement("h4")
        const res = document.createElement("h4")

        container.appendChild(img);
        container.appendChild(title);
        container.appendChild(par);
        container.appendChild(auteur);

        edit.textContent = "Editeur : "+livre.éditeur;
        date.textContent = "Date de publication : "+livre.date;
        genre.textContent = "Genre : "+livre.genre;
        langue.textContent = "Langue : "+livre.langue;
        nbr.textContent = "Nombre de pages : "+livre.nombre_de_pages;
        isbn.textContent = "ISBN : "+livre.ISBN;
        etat.textContent = "Etat : "+livre.etat;
        dispo.textContent = "Disponibilité : "+livre.dispo;
        res.textContent = "Resumé : "+livre.resume;

        container.appendChild(edit)
        container.appendChild(date)
        container.appendChild(genre)
        container.appendChild(langue)
        container.appendChild(nbr)
        container.appendChild(isbn)
        container.appendChild(etat)
        container.appendChild(dispo)
        container.appendChild(res)
        container.style.display = 'flex'

}